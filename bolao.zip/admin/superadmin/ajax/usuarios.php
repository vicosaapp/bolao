<?php
session_start();

// Configurar cabeçalho para resposta JSON
header('Content-Type: application/json');

// Verificar permissão de acesso (nível mínimo de administrador)
require_once '../../auth.php';
requireAccess(3);

// Incluir modelo de usuário
require_once '../../models/UsuarioModel.php';

// Inicializar modelo de usuário
$usuarioModel = new UsuarioModel();

// Processar ação solicitada
$action = $_GET['action'] ?? null;

try {
    switch ($action) {
        case 'adicionar':
            // Validar dados de entrada
            $nome = $_POST['nome'] ?? null;
            $email = $_POST['email'] ?? null;
            $senha = $_POST['senha'] ?? null;
            $nivel = $_POST['nivel'] ?? null;
            $status = $_POST['status'] ?? null;

            // Verificar campos obrigatórios
            if (!$nome || !$email || !$senha || !$nivel || !$status) {
                throw new Exception('Todos os campos são obrigatórios.');
            }

            // Validar email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Email inválido.');
            }

            // Adicionar usuário
            $usuarioId = $usuarioModel->adicionarUsuario($nome, $email, $senha, $nivel, $status);

            echo json_encode([
                'success' => true, 
                'message' => 'Usuário adicionado com sucesso!', 
                'id' => $usuarioId
            ]);
            break;

        case 'excluir':
            // Validar ID do usuário
            $usuarioId = $_GET['id'] ?? null;

            if (!$usuarioId) {
                throw new Exception('ID do usuário não fornecido.');
            }

            // Impedir exclusão do próprio usuário
            if ($usuarioId == $_SESSION['usuario_id']) {
                throw new Exception('Você não pode excluir sua própria conta.');
            }

            // Excluir usuário
            $resultado = $usuarioModel->excluirUsuario($usuarioId);

            echo json_encode([
                'success' => true, 
                'message' => 'Usuário excluído com sucesso!'
            ]);
            break;

        case 'atualizar':
            // Validar dados de entrada
            $usuarioId = $_POST['id'] ?? null;
            $nome = $_POST['nome'] ?? null;
            $email = $_POST['email'] ?? null;
            $nivel = $_POST['nivel'] ?? null;
            $status = $_POST['status'] ?? null;

            // Verificar campos obrigatórios
            if (!$usuarioId || !$nome || !$email || !$nivel || !$status) {
                throw new Exception('Todos os campos são obrigatórios.');
            }

            // Validar email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Email inválido.');
            }

            // Atualizar usuário
            $resultado = $usuarioModel->atualizarUsuario($usuarioId, $nome, $email, $nivel, $status);

            echo json_encode([
                'success' => true, 
                'message' => 'Usuário atualizado com sucesso!'
            ]);
            break;

        default:
            throw new Exception('Ação inválida.');
    }
} catch (Exception $e) {
    // Resposta de erro
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?> 