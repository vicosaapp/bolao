<?php
// Configurar cabeçalho para JSON
header('Content-Type: application/json');

// Verificar se o método é GET e se o ID foi fornecido
if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'ID da venda não fornecido']);
    exit;
}

// Incluir autenticação
require_once '../../auth.php';

// Verificar se o usuário está logado e tem permissão de administrador
if (!isLoggedIn() || !hasAccess(3)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Acesso não autorizado']);
    exit;
}

// Incluir os modelos necessários
require_once '../../models/BilheteModel.php';

// Obter o ID da venda
$id = (int) $_GET['id'];

// Inicializar modelo
$bilheteModel = new BilheteModel();

try {
    // Incluir configuração do banco de dados para acessar a conexão
    require_once dirname(__DIR__, 3) . '/config/database.php';
    
    // Consultar detalhes do bilhete no banco de dados
    $query = "SELECT b.id, b.numero, c.nome AS concurso, b.valor, b.status, b.data_compra,
                     u.nome AS vendedor, a.nome AS apostador_nome, a.email AS apostador_email,
                     a.telefone AS apostador_telefone
              FROM bilhetes b
              LEFT JOIN concursos c ON b.concurso_id = c.id
              LEFT JOIN usuarios u ON b.vendedor_id = u.id
              LEFT JOIN apostadores a ON b.apostador_id = a.id
              WHERE b.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Venda não encontrada']);
        exit;
    }
    
    $venda = $result->fetch_assoc();
    
    // Formatar dados para retorno
    $resposta = [
        'sucesso' => true,
        'id' => $venda['id'],
        'numero' => $venda['numero'],
        'concurso' => $venda['concurso'],
        'valor' => $venda['valor'],
        'status' => $venda['status'],
        'data_compra' => $venda['data_compra'],
        'vendedor' => $venda['vendedor'],
        'apostador' => [
            'nome' => $venda['apostador_nome'],
            'email' => $venda['apostador_email'],
            'telefone' => $venda['apostador_telefone']
        ]
    ];
    
    echo json_encode($resposta);
    
} catch (Exception $e) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao obter detalhes: ' . $e->getMessage()]);
}
?> 