document.addEventListener('DOMContentLoaded', function() {
    // Referências aos elementos
    const formNovoUsuario = document.getElementById('formNovoUsuario');
    const salvarNovoUsuario = document.getElementById('salvarNovoUsuario');
    const buscarUsuario = document.getElementById('buscarUsuario');
    const botoesExcluir = document.querySelectorAll('.btn-excluir');

    // Função para mostrar alertas
    function mostrarAlerta(mensagem, tipo = 'success') {
        const alerta = document.createElement('div');
        alerta.className = `alert alert-${tipo} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        alerta.style.zIndex = '9999';
        alerta.innerHTML = `
            ${mensagem}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alerta);

        // Remover alerta após 3 segundos
        setTimeout(() => {
            const bootstrapAlerta = new bootstrap.Alert(alerta);
            bootstrapAlerta.close();
        }, 3000);
    }

    // Adicionar novo usuário
    if (salvarNovoUsuario) {
        salvarNovoUsuario.addEventListener('click', function() {
            const formData = new FormData(formNovoUsuario);

            fetch('superadmin/ajax/usuarios.php?action=adicionar', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    mostrarAlerta('Usuário adicionado com sucesso!');
                    // Fechar modal e atualizar lista
                    const modal = bootstrap.Modal.getInstance(document.getElementById('novoUsuarioModal'));
                    modal.hide();
                    setTimeout(() => location.reload(), 500);
                } else {
                    mostrarAlerta(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                mostrarAlerta('Erro ao adicionar usuário', 'danger');
            });
        });
    }

    // Buscar usuário
    if (buscarUsuario) {
        buscarUsuario.addEventListener('input', function() {
            const termoBusca = this.value.toLowerCase();
            const linhas = document.querySelectorAll('.table tbody tr');

            linhas.forEach(linha => {
                const texto = linha.textContent.toLowerCase();
                linha.style.display = texto.includes(termoBusca) ? '' : 'none';
            });
        });
    }

    // Excluir usuário
    botoesExcluir.forEach(botao => {
        botao.addEventListener('click', function() {
            const usuarioId = this.getAttribute('data-id');
            
            // Confirmação de exclusão
            if (confirm('Tem certeza que deseja excluir este usuário?')) {
                fetch(`superadmin/ajax/usuarios.php?action=excluir&id=${usuarioId}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarAlerta('Usuário excluído com sucesso!');
                        // Remover linha da tabela
                        this.closest('tr').remove();
                    } else {
                        mostrarAlerta(data.message, 'danger');
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    mostrarAlerta('Erro ao excluir usuário', 'danger');
                });
            }
        });
    });
}); 