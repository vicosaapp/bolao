document.addEventListener('DOMContentLoaded', function() {
    // Referências aos elementos
    const botoesExcluir = document.querySelectorAll('.btn-cancelar-bilhete');

    // Função para mostrar alertas
    function mostrarAlerta(mensagem, tipo = 'success') {
        const alerta = document.createElement('div');
        alerta.className = `alert alert-${tipo} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        alerta.style.zIndex = '9999';
        alerta.innerHTML = `
            ${mensagem}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alerta);

        // Remover alerta após 3 segundos
        setTimeout(() => {
            const bootstrapAlerta = new bootstrap.Alert(alerta);
            bootstrapAlerta.close();
        }, 3000);
    }

    // Cancelar bilhete
    botoesExcluir.forEach(botao => {
        botao.addEventListener('click', function() {
            const bilheteId = this.getAttribute('data-id');
            
            // Confirmação de cancelamento
            if (confirm('Tem certeza que deseja cancelar este bilhete?')) {
                fetch(`ajax/bilhetes.php?action=cancelar&id=${bilheteId}`, {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarAlerta('Bilhete cancelado com sucesso!');
                        // Remover linha da tabela ou atualizar status
                        const linha = this.closest('tr');
                        const statusCell = linha.querySelector('td:nth-child(5) .badge');
                        statusCell.className = 'badge bg-danger';
                        statusCell.textContent = 'Cancelado';
                        
                        // Remover botão de cancelamento
                        this.remove();
                    } else {
                        mostrarAlerta(data.message, 'danger');
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    mostrarAlerta('Erro ao cancelar bilhete', 'danger');
                });
            }
        });
    });
}); 