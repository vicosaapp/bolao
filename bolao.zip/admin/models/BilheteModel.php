<?php
class BilheteModel {
    private $conn;

    public function __construct() {
        require_once dirname(__DIR__, 2) . '/config/database.php';
        $this->conn = $conn;
    }

    /**
     * Contar total de bilhetes
     * @return int Número total de bilhetes
     */
    public function contarBilhetes() {
        $query = "SELECT COUNT(*) AS total FROM bilhetes";
        $result = $this->conn->query($query);
        $row = $result->fetch_assoc();
        return $row['total'];
    }

    /**
     * Calcular total de vendas
     * @return float Valor total de vendas
     */
    public function calcularTotalVendas() {
        $query = "SELECT SUM(valor) AS total FROM bilhetes WHERE status = 'pago'";
        $result = $this->conn->query($query);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }

    /**
     * Listar bilhetes
     * @param int $limite Número máximo de bilhetes a retornar
     * @return array Lista de bilhetes
     */
    public function listarBilhetes($limite = 10) {
        $bilhetes = [];
        $query = "SELECT b.id, b.numero, c.nome AS concurso, a.nome AS apostador, 
                         b.valor, b.status, b.data_compra 
                  FROM bilhetes b
                  LEFT JOIN concursos c ON b.concurso_id = c.id
                  LEFT JOIN apostadores a ON b.apostador_id = a.id
                  ORDER BY b.data_compra DESC 
                  LIMIT ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $limite);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $bilhetes[] = $row;
        }

        return $bilhetes;
    }

    /**
     * Adicionar novo bilhete
     * @param array $dados Dados do bilhete
     * @return int|false ID do bilhete inserido ou false em caso de erro
     */
    public function adicionarBilhete($dados) {
        $numero = $this->conn->real_escape_string($dados['numero']);
        $concursoId = intval($dados['concurso_id']);
        $apostadorId = intval($dados['apostador_id'] ?? 0);
        $vendedorId = intval($dados['vendedor_id'] ?? 0);
        $valor = floatval($dados['valor']);
        $status = $this->conn->real_escape_string($dados['status'] ?? 'pago');

        $query = "INSERT INTO bilhetes (numero, concurso_id, apostador_id, vendedor_id, valor, status) 
                  VALUES ('$numero', $concursoId, $apostadorId, $vendedorId, $valor, '$status')";
        
        if ($this->conn->query($query)) {
            return $this->conn->insert_id;
        }

        return false;
    }

    /**
     * Atualizar status do bilhete
     * @param int $id ID do bilhete
     * @param string $status Novo status
     * @return bool Sucesso da operação
     */
    public function atualizarStatusBilhete($id, $status) {
        $status = $this->conn->real_escape_string($status);
        $query = "UPDATE bilhetes SET status = '$status' WHERE id = $id";
        return $this->conn->query($query);
    }

    /**
     * Listar bilhetes com filtros
     * @param array $filtros Filtros para busca de bilhetes
     * @return array Lista de bilhetes
     */
    public function listarBilhetesComFiltros($filtros) {
        $bilhetes = [];
        
        // Preparar parâmetros de filtro
        $status = $filtros['status'] ?? null;
        $concursoId = $filtros['concurso_id'] ?? null;
        $limite = $filtros['limite'] ?? 10;
        $offset = $filtros['offset'] ?? 0;

        // Construir query base
        $query = "SELECT b.id, b.numero, c.nome AS concurso, 
                         b.valor, b.status, b.data_compra 
                  FROM bilhetes b
                  LEFT JOIN concursos c ON b.concurso_id = c.id
                  WHERE 1=1";

        // Adicionar filtros
        $params = [];
        $tipos = '';

        if ($status) {
            $query .= " AND b.status = ?";
            $params[] = $status;
            $tipos .= 's';
        }

        if ($concursoId) {
            $query .= " AND b.concurso_id = ?";
            $params[] = $concursoId;
            $tipos .= 'i';
        }

        // Adicionar ordenação e limite
        $query .= " ORDER BY b.data_compra DESC LIMIT ? OFFSET ?";
        $params[] = $limite;
        $params[] = $offset;
        $tipos .= 'ii';

        // Preparar e executar statement
        $stmt = $this->conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($tipos, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $bilhetes[] = $row;
        }

        return $bilhetes;
    }

    /**
     * Contar bilhetes com filtros
     * @param array $filtros Filtros para contagem de bilhetes
     * @return int Número total de bilhetes
     */
    public function contarBilhetesComFiltros($filtros) {
        // Preparar parâmetros de filtro
        $status = $filtros['status'] ?? null;
        $concursoId = $filtros['concurso_id'] ?? null;

        // Construir query base
        $query = "SELECT COUNT(*) AS total FROM bilhetes WHERE 1=1";

        // Adicionar filtros
        $params = [];
        $tipos = '';

        if ($status) {
            $query .= " AND status = ?";
            $params[] = $status;
            $tipos .= 's';
        }

        if ($concursoId) {
            $query .= " AND concurso_id = ?";
            $params[] = $concursoId;
            $tipos .= 'i';
        }

        // Preparar e executar statement
        $stmt = $this->conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($tipos, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return $row['total'];
    }
}
?> 