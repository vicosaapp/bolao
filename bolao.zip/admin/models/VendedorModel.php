<?php
// Incluir a classe de banco de dados
require_once dirname(__DIR__, 2) . '/includes/Database.php';

class VendedorModel {
    private $conn;
    private $database;

    public function __construct() {
        try {
            // Obter instância do banco de dados
            $this->database = Database::getInstance();
            $this->conn = $this->database->getConnection();
        } catch (Exception $e) {
            // Log do erro
            error_log("Erro ao estabelecer conexão no modelo de Vendedor: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Obter top vendedores
     * @param int $limite Número de vendedores a retornar
     * @return array Lista de vendedores com suas vendas
     */
    public function obterTopVendedores($limite = 5) {
        $vendedores = [];
        $query = "SELECT 
                    v.id, 
                    v.codigo, 
                    v.nome, 
                    v.comissao,
                    COALESCE(SUM(b.valor), 0) AS total_vendas,
                    COALESCE(SUM(b.valor * v.comissao / 100), 0) AS comissao_total
                  FROM vendedores v
                  LEFT JOIN bilhetes b ON v.id = b.vendedor_id AND b.status = 'pago'
                  GROUP BY v.id, v.codigo, v.nome, v.comissao
                  ORDER BY total_vendas DESC
                  LIMIT ?";
        
        try {
            $stmt = $this->database->executeQuery($query, [$limite], 'i');
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $vendedores[] = $row;
            }

            return $vendedores;
        } catch (Exception $e) {
            error_log("Erro ao obter top vendedores: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Adicionar novo vendedor
     * @param array $dados Dados do vendedor
     * @return int|false ID do vendedor inserido ou false em caso de erro
     */
    public function adicionarVendedor($dados) {
        try {
            $query = "INSERT INTO vendedores (codigo, nome, telefone, email, comissao) 
                      VALUES (?, ?, ?, ?, ?)";
            
            $stmt = $this->database->executeQuery($query, [
                $dados['codigo'], 
                $dados['nome'], 
                $dados['telefone'] ?? '', 
                $dados['email'] ?? '', 
                floatval($dados['comissao'] ?? 10.00)
            ], 'ssssd');

            return $this->conn->insert_id;
        } catch (Exception $e) {
            error_log("Erro ao adicionar vendedor: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Listar vendedores
     * @param int $limite Número máximo de vendedores a retornar
     * @return array Lista de vendedores
     */
    public function listarVendedores($limite = 10) {
        $vendedores = [];
        $query = "SELECT id, codigo, nome, telefone, email, comissao, 
                         (SELECT COALESCE(SUM(valor), 0) 
                          FROM bilhetes 
                          WHERE vendedor_id = vendedores.id AND status = 'pago') AS total_vendas
                  FROM vendedores
                  ORDER BY total_vendas DESC
                  LIMIT ?";
        
        try {
            $stmt = $this->database->executeQuery($query, [$limite], 'i');
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $vendedores[] = $row;
            }

            return $vendedores;
        } catch (Exception $e) {
            error_log("Erro ao listar vendedores: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Atualizar dados do vendedor
     * @param int $id ID do vendedor
     * @param array $dados Dados atualizados do vendedor
     * @return bool Sucesso da operação
     */
    public function atualizarVendedor($id, $dados) {
        try {
            $query = "UPDATE vendedores 
                      SET nome = ?, 
                          telefone = ?, 
                          email = ?, 
                          comissao = ? 
                      WHERE id = ?";
            
            $this->database->executeQuery($query, [
                $dados['nome'], 
                $dados['telefone'] ?? '', 
                $dados['email'] ?? '', 
                floatval($dados['comissao'] ?? 10.00),
                $id
            ], 'sssdi');

            return true;
        } catch (Exception $e) {
            error_log("Erro ao atualizar vendedor: " . $e->getMessage());
            return false;
        }
    }
}
?> 