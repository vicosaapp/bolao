<?php
// Incluir a classe de banco de dados
require_once dirname(__DIR__, 2) . '/includes/Database.php';

class ConcursoModel {
    private $conn;
    private $database;

    public function __construct() {
        try {
            // Obter instância do banco de dados
            $this->database = Database::getInstance();
            $this->conn = $this->database->getConnection();
        } catch (Exception $e) {
            // Log do erro
            error_log("Erro ao estabelecer conexão no modelo de Concurso: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Contar total de concursos
     * @return int Número total de concursos
     */
    public function contarConcursos() {
        $query = "SELECT COUNT(*) AS total FROM concursos";
        $result = $this->conn->query($query);
        $row = $result->fetch_assoc();
        return $row['total'];
    }

    /**
     * Contar concursos ativos
     * @return int Número de concursos em andamento
     */
    public function contarConcursosAtivos() {
        $query = "SELECT COUNT(*) AS total FROM concursos WHERE status = 'em_andamento'";
        $result = $this->conn->query($query);
        $row = $result->fetch_assoc();
        return $row['total'];
    }

    /**
     * Listar concursos
     * @param int $limite Número máximo de concursos a retornar
     * @return array Lista de concursos
     */
    public function listarConcursos($limite = 10) {
        $concursos = [];
        $query = "SELECT id, numero, nome, data_inicio, data_fim, status, valor_premios 
                  FROM concursos 
                  ORDER BY data_inicio DESC 
                  LIMIT ?";
        
        try {
            $stmt = $this->database->executeQuery($query, [$limite], 'i');
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $concursos[] = $row;
            }

            return $concursos;
        } catch (Exception $e) {
            error_log("Erro ao listar concursos: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Adicionar novo concurso
     * @param array $dados Dados do concurso
     * @return int|false ID do concurso inserido ou false em caso de erro
     */
    public function adicionarConcurso($dados) {
        try {
            $query = "INSERT INTO concursos (numero, nome, data_inicio, data_fim, valor_premios) 
                      VALUES (?, ?, ?, ?, ?)";
            
            $stmt = $this->database->executeQuery($query, [
                $dados['numero'], 
                $dados['nome'], 
                $dados['data_inicio'], 
                $dados['data_fim'], 
                $dados['valor_premios']
            ], 'isssd');

            return $this->conn->insert_id;
        } catch (Exception $e) {
            error_log("Erro ao adicionar concurso: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Atualizar status do concurso
     * @param int $id ID do concurso
     * @param string $status Novo status
     * @return bool Sucesso da operação
     */
    public function atualizarStatusConcurso($id, $status) {
        try {
            $query = "UPDATE concursos SET status = ? WHERE id = ?";
            $this->database->executeQuery($query, [$status, $id], 'si');
            return true;
        } catch (Exception $e) {
            error_log("Erro ao atualizar status do concurso: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Listar concursos com filtros
     * @param array $filtros Filtros para busca de concursos
     * @return array Lista de concursos
     */
    public function listarConcursosComFiltros($filtros = []) {
        $concursos = [];
        
        // Construir query base
        $query = "SELECT id, numero, nome, data_inicio, data_fim, status, valor_premios 
                  FROM concursos 
                  WHERE 1=1";
        
        // Adicionar filtro de status, se fornecido
        $params = [];
        $types = '';
        
        if (!empty($filtros['status'])) {
            $query .= " AND status = ?";
            $params[] = $filtros['status'];
            $types .= 's';
        }
        
        // Adicionar ordenação
        $query .= " ORDER BY data_inicio DESC";
        
        // Adicionar limite e offset
        if (isset($filtros['limite'])) {
            $query .= " LIMIT ?";
            $params[] = $filtros['limite'];
            $types .= 'i';
            
            if (isset($filtros['offset'])) {
                $query .= " OFFSET ?";
                $params[] = $filtros['offset'];
                $types .= 'i';
            }
        }
        
        try {
            // Preparar e executar a consulta
            $stmt = $this->database->executeQuery($query, $params, $types);
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $concursos[] = $row;
            }

            return $concursos;
        } catch (Exception $e) {
            error_log("Erro ao listar concursos: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Contar concursos com filtros
     * @param array $filtros Filtros para contagem de concursos
     * @return int Número total de concursos
     */
    public function contarConcursosComFiltros($filtros = []) {
        // Construir query base
        $query = "SELECT COUNT(*) AS total FROM concursos WHERE 1=1";
        
        // Adicionar filtro de status, se fornecido
        $params = [];
        $types = '';
        
        if (!empty($filtros['status'])) {
            $query .= " AND status = ?";
            $params[] = $filtros['status'];
            $types .= 's';
        }
        
        try {
            // Preparar e executar a consulta
            $stmt = $this->database->executeQuery($query, $params, $types);
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            return $row['total'];
        } catch (Exception $e) {
            error_log("Erro ao contar concursos: " . $e->getMessage());
            return 0;
        }
    }
}
?> 