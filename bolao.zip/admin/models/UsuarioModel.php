<?php
class UsuarioModel {
    private $conn;

    public function __construct() {
        try {
            // Incluir arquivo de conexão com o banco de dados
            error_log("[UsuarioModel] Iniciando construtor UsuarioModel");
            
            // Verificar se já existe uma conexão global
            global $conn;
            if (isset($conn) && ($conn instanceof mysqli) && !$conn->connect_error) {
                error_log("[UsuarioModel] Usando conexão global existente");
                $this->conn = $conn;
                return;
            }
            
            // Tentar arquivo principal /config/database.php
            $database_path = dirname(__DIR__, 2) . '/config/database.php';
            error_log("[UsuarioModel] Tentando usar arquivo: " . $database_path);
            
            if (file_exists($database_path)) {
                include_once $database_path;
                
                if (isset($conn) && ($conn instanceof mysqli) && !$conn->connect_error) {
                    error_log("[UsuarioModel] Conexão bem-sucedida via /config/database.php");
                    $this->conn = $conn;
                    return;
                }
            }
            
            // Tentar arquivo alternativo /includes/db_config.php
            $alternate_path = dirname(__DIR__, 2) . '/includes/db_config.php';
            error_log("[UsuarioModel] Tentando usar arquivo alternativo: " . $alternate_path);
            
            if (file_exists($alternate_path)) {
                include_once $alternate_path;
                
                if (isset($conn) && ($conn instanceof mysqli) && !$conn->connect_error) {
                    error_log("[UsuarioModel] Conexão bem-sucedida via /includes/db_config.php");
                    $this->conn = $conn;
                    return;
                }
            }
            
            // Se chegou aqui, tentar criar uma conexão direta
            error_log("[UsuarioModel] Tentando criar conexão direta");
            
            $host = 'localhost';
            $usuario = 'root';
            $senha = '';
            $banco = 'bolao_db';
            
            $conn = new mysqli($host, $usuario, $senha, $banco);
            
            if ($conn->connect_error) {
                throw new Exception("Erro na conexão direta com o banco de dados: " . $conn->connect_error);
            }
            
            $conn->set_charset("utf8mb4");
            $this->conn = $conn;
            error_log("[UsuarioModel] Conexão direta estabelecida com sucesso");
            
        } catch (Exception $e) {
            error_log("[UsuarioModel] ERRO no construtor: " . $e->getMessage());
            throw $e; // Repassar a exceção
        }
    }

    /**
     * Listar todos os usuários
     * @return array Lista de usuários
     */
    public function listarUsuarios() {
        $usuarios = [];
        $query = "SELECT id, nome, email, tipo AS nivel, status FROM usuarios ORDER BY id DESC";
        $result = $this->conn->query($query);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                // Mapear o tipo para o nível de acesso
                $niveis = [
                    'admin' => 4,     // Super Admin
                    'operador' => 3   // Administrador
                ];
                $row['nivel'] = $niveis[$row['nivel']] ?? 1;
                $usuarios[] = $row;
            }
        }

        return $usuarios;
    }

    /**
     * Adicionar novo usuário
     * @param string $nome Nome do usuário
     * @param string $email Email do usuário
     * @param string $senha Senha do usuário
     * @param int $nivel Nível de acesso
     * @param string $status Status do usuário
     * @return int|false ID do usuário inserido ou false em caso de erro
     */
    public function adicionarUsuario($nome, $email, $senha, $nivel, $status) {
        // Mapear nível para tipo de usuário
        $tipos = [
            1 => 'operador',  // Apostador
            2 => 'operador',  // Revendedor
            3 => 'operador',  // Administrador
            4 => 'admin'      // Super Admin
        ];
        $tipo = $tipos[$nivel] ?? 'operador';

        // Preparar dados
        $nome = $this->conn->real_escape_string($nome);
        $email = $this->conn->real_escape_string($email);
        $usuario = strtolower(str_replace(' ', '_', $nome));
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $status_db = $status == 'ativo' ? 'ativo' : 'inativo';

        // Construir query
        $query = "INSERT INTO usuarios (nome, usuario, email, senha, tipo, status) VALUES ('$nome', '$usuario', '$email', '$senha_hash', '$tipo', '$status_db')";
        
        if ($this->conn->query($query)) {
            return $this->conn->insert_id;
        }

        return false;
    }

    /**
     * Atualizar usuário
     * @param int $id ID do usuário
     * @param string $nome Nome do usuário
     * @param string $email Email do usuário
     * @param int $nivel Nível de acesso
     * @param string $status Status do usuário
     * @param string|null $senha Senha do usuário (opcional)
     * @return bool Sucesso da operação
     */
    public function atualizarUsuario($id, $nome, $email, $nivel, $status, $senha = null) {
        // Mapear nível para tipo de usuário
        $tipos = [
            1 => 'operador',  // Apostador
            2 => 'operador',  // Revendedor
            3 => 'operador',  // Administrador
            4 => 'admin'      // Super Admin
        ];
        $tipo = $tipos[$nivel] ?? 'operador';

        // Preparar dados
        $nome = $this->conn->real_escape_string($nome);
        $email = $this->conn->real_escape_string($email);
        $status_db = $status == 'ativo' ? 'ativo' : 'inativo';

        // Construir query
        $query = "UPDATE usuarios SET nome = '$nome', email = '$email', tipo = '$tipo', status = '$status_db'";

        // Adicionar atualização de senha se fornecida
        if (!empty($senha)) {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $query .= ", senha = '$senha_hash'";
        }

        $query .= " WHERE id = $id";
        
        return $this->conn->query($query);
    }

    /**
     * Excluir usuário
     * @param int $id ID do usuário
     * @return bool Sucesso da operação
     */
    public function excluirUsuario($id) {
        $query = "DELETE FROM usuarios WHERE id = $id";
        return $this->conn->query($query);
    }

    /**
     * Buscar usuário por ID
     * @param int $id ID do usuário
     * @return array|null Dados do usuário ou null
     */
    public function buscarUsuarioPorId($id) {
        $query = "SELECT * FROM usuarios WHERE id = $id";
        $result = $this->conn->query($query);

        return $result ? $result->fetch_assoc() : null;
    }

    /**
     * Verificar credenciais de login
     * @param string $email Email do usuário
     * @param string $senha Senha do usuário
     * @return array|false Dados do usuário ou false
     */
    public function verificarLogin($email, $senha) {
        $email = $this->conn->real_escape_string($email);

        $query = "SELECT * FROM usuarios WHERE email = '$email'";
        $result = $this->conn->query($query);

        if ($result && $result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            
            // Verificar senha
            if (password_verify($senha, $usuario['senha'])) {
                // Remover senha antes de retornar
                unset($usuario['senha']);
                return $usuario;
            }
        }

        return false;
    }

    /**
     * Obter usuário por ID
     * @param int $id ID do usuário
     * @return array|null Dados do usuário ou null se não encontrado
     */
    public function obterUsuarioPorId($id) {
        // Validar entrada
        error_log("[UsuarioModel] Buscando usuário com ID: " . $id);
        
        if (!$id) {
            error_log("[UsuarioModel] ID de usuário inválido: " . $id);
            return null;
        }

        $id = $this->conn->real_escape_string($id);
        $query = "SELECT id, nome, email, telefone, tipo AS nivel_acesso 
                  FROM usuarios 
                  WHERE id = '$id'";
        
        error_log("[UsuarioModel] Executando query: " . $query);
        $result = $this->conn->query($query);

        if ($result && $result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            error_log("[UsuarioModel] Usuário encontrado: " . print_r($usuario, true));
            
            // Mapear tipo para nível de acesso
            $niveis = [
                'operador' => 1,  // Vendedor
                'admin' => 3      // Administrador
            ];
            $usuario['nivel_acesso'] = $niveis[$usuario['nivel_acesso']] ?? 1;

            // Garantir que todos os campos existam
            $usuario['nome'] = $usuario['nome'] ?? '';
            $usuario['email'] = $usuario['email'] ?? '';
            $usuario['telefone'] = $usuario['telefone'] ?? '';

            return $usuario;
        }

        error_log("[UsuarioModel] Usuário não encontrado com ID: " . $id);
        // Retornar array vazio em vez de null para evitar erros
        return [
            'id' => null,
            'nome' => '',
            'email' => '',
            'telefone' => '',
            'nivel_acesso' => 1
        ];
    }

    /**
     * Atualizar perfil do usuário
     * @param int $id ID do usuário
     * @param array $dados Dados para atualização
     * @return bool Sucesso da operação
     */
    public function atualizarPerfil($id, $dados) {
        error_log("[UsuarioModel] Atualizando perfil do usuário ID: " . $id . " com dados: " . print_r($dados, true));
        
        // Preparar dados
        $nome = $this->conn->real_escape_string($dados['nome']);
        $email = $this->conn->real_escape_string($dados['email']);
        $telefone = $this->conn->real_escape_string($dados['telefone'] ?? '');
        $id = $this->conn->real_escape_string($id);

        $query = "UPDATE usuarios 
                  SET nome = '$nome', 
                      email = '$email', 
                      telefone = '$telefone' 
                  WHERE id = '$id'";
        
        error_log("[UsuarioModel] Executando query de atualização: " . $query);
        $resultado = $this->conn->query($query);
        error_log("[UsuarioModel] Resultado da atualização: " . ($resultado ? "Sucesso" : "Falha - " . $this->conn->error));
        
        return $resultado;
    }

    /**
     * Alterar senha do usuário
     * @param int $id ID do usuário
     * @param string $senhaAtual Senha atual
     * @param string $novaSenha Nova senha
     * @return bool Sucesso da operação
     */
    public function alterarSenha($id, $senhaAtual, $novaSenha) {
        error_log("[UsuarioModel] Alterando senha do usuário ID: " . $id);
        
        $id = $this->conn->real_escape_string($id);

        // Primeiro, verificar se a senha atual está correta
        $query = "SELECT senha FROM usuarios WHERE id = '$id'";
        error_log("[UsuarioModel] Verificando senha atual: " . $query);
        
        $result = $this->conn->query($query);

        if ($result && $result->num_rows > 0) {
            $usuario = $result->fetch_assoc();

            // Verificar senha atual
            if (!password_verify($senhaAtual, $usuario['senha'])) {
                error_log("[UsuarioModel] Senha atual incorreta para usuário ID: " . $id);
                return false;
            }

            // Atualizar senha
            $novaSenhaCriptografada = password_hash($novaSenha, PASSWORD_DEFAULT);
            $novaSenhaCriptografada = $this->conn->real_escape_string($novaSenhaCriptografada);

            $query = "UPDATE usuarios SET senha = '$novaSenhaCriptografada' WHERE id = '$id'";
            error_log("[UsuarioModel] Atualizando senha: " . $query);
            
            $resultado = $this->conn->query($query);
            error_log("[UsuarioModel] Resultado da atualização de senha: " . ($resultado ? "Sucesso" : "Falha - " . $this->conn->error));
            
            return $resultado;
        }

        error_log("[UsuarioModel] Usuário não encontrado para alteração de senha, ID: " . $id);
        return false;
    }
}
?> 